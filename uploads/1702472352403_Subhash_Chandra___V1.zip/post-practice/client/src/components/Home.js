import React, { useEffect, useRef, useState } from 'react'
import { useLocation } from 'react-router-dom'

function Home() {

    let loc = useLocation();

    let genderSelectRef = useRef();
    let ageSelectRef = useRef();
    let countrySelectRef = useRef();

    const [dropdownOptions, setdropdownOptions] = useState({
        gender: [],
        age: [],
        country: [],
    })

 

    let getaccounts = async () => {
        let reqOptions = {
            method: "GET",
        }

        let url = `http://localhost:1234/accountsInfo?gender=${genderSelectRef.current.value}&age=${ageSelectRef.current.value}&country=${countrySelectRef.current.value}`;

        let JSONData = await fetch(url, reqOptions);
        let JSOData = await JSONData.json();

        console.log(JSOData);
    }

    let getDropDownOptions = async () => {
        try {
            let reqOptions = {
                method: "GET",
            }
    
            let JSONData = await fetch("http://localhost:1234/dropdownOptions", reqOptions);
            let JSOData = await JSONData.json();
    
            console.log(JSOData);
    
            setdropdownOptions(JSOData);
        } catch (error) {
            console.error("Error fetching dropdown options", error);
        }
    }
    

       useEffect(()=>{
        getDropDownOptions();
    },[])
  return (
    <div>
        <div className='heading'>
            <h2>ConnectHub🫂</h2>

            <div>
                {loc.state && loc.state.firstName && loc.state.lastName ? (
                    <h2 style={{color:"black"}}>Welcome, {loc.state.firstName} {loc.state.lastName}.</h2>
                ) : ("")}
            </div>

            <form>
                <div>
                   <select>
                    <option>Select Gender</option>
                    {dropdownOptions.gender.map((ele,index)=>{
                        return <option key={index}>{ele}</option>
                    })}
                   </select>
                   <select>
                    <option>Select Age</option>
                    {dropdownOptions.age.map((ele,index)=>{
                        return <option key={index}>{ele}</option>
                    })}
                   </select>
                   <select>
                    <option>Select Country</option>
                    {dropdownOptions.country.map((ele,index)=>{
                        return <option key={index}>{ele}</option>
                    })}
                   </select>
                        <button onClick={()=>{getaccounts();}} type='button' className='homebtn'>Find</button>
                </div>
            </form>
        </div>

    </div>
  )
}

export default Home