import React from 'react'
import {Link} from "react-router-dom";
function Login() {
  return (
    <div>
         <header>
            <h1>ConnectHub🫂</h1>
        </header>
        <h4>Securely connect with friends and share your world. 🌍 Log in to join the fun!

</h4>
    <div className='login'>
        <form>
            <div>
                <input placeholder='Email Address or Phone number' className='logininput'></input>
            </div>
            <div>
                <input placeholder='password' className='logininput'></input>
            </div>
            <div>
                <button className='loginbtn'>Login</button>
            </div>
        </form>
        <br></br>
        <Link to="/signup"><button  className='signupbtn2'>Signup</button></Link>
    </div>
    </div>
  )
}

export default Login