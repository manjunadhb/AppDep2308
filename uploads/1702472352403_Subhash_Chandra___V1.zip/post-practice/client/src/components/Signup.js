import React, { useRef } from 'react'
import {Link, useNavigate} from "react-router-dom";


function Signup() {

    let fnameinputRef = useRef();
    let lnameinputRef = useRef();
    let emailinputRef = useRef();
    let passwordinputRef = useRef();
    let cpasswordinputRef = useRef();
    let phoneinputRef = useRef();
    let birthdayinputRef = useRef();
    let genderinputRef = useRef();
    let addressinputRef = useRef();

    let navigate = useNavigate();

    let sendData =  async () => {
        let dataToInsert = {
            firstName: fnameinputRef.current.value,
            lastName: lnameinputRef.current.value,
            phone:phoneinputRef.current.value,
            email:emailinputRef.current.value,
            password:passwordinputRef.current.value,
            confirmPassword: cpasswordinputRef.current.value,
            address: addressinputRef.current.value,
            birthday: birthdayinputRef.current.value,
            gender: genderinputRef.current.value,
        }

        console.log(dataToInsert);

        let datatoSendJSON = JSON.stringify(dataToInsert);

        let myHeaders = new Headers();
        myHeaders.append("content-type","application/json");

        let reqOptions = {
            method: "POST",
            body: datatoSendJSON,
            headers: myHeaders,
        }

        let JSONData = await fetch("http://localhost:1234/signup",reqOptions);
        let JSOData = await JSONData.json();

        console.log(JSOData);

        navigate('/home',{state:{firstName:fnameinputRef.current.value, lastName:lnameinputRef.current.value}});
    }
  return (
    <div>
        <header>
            <h1>ConnectHub🫂</h1>
        </header>
        <h4>We're thrilled to have you here again! Your social world awaits – catch up with friends, share your stories, and explore new connections.</h4>
    <div className='signup'>
        <form>
            <div>
                <input ref={fnameinputRef} placeholder='FirstName'></input>
                <input ref={lnameinputRef} placeholder='LastName'></input>
            </div>
            <div>
                <input ref={phoneinputRef} type='number' placeholder='Mobile Number'></input>
            </div>
            <div>
                <input ref={emailinputRef} placeholder='Email Address'></input>
            </div>
            <div>
                <input ref={passwordinputRef} placeholder='Password'></input>
            </div>
            <div>
                <input ref={cpasswordinputRef} placeholder='Confirm Password'></input>
            </div>
            <div>
                <input ref={addressinputRef} placeholder='Address'></input>
            </div>
            <div>
                <label className='signuplabel'>Birthday:</label>
                <input ref={birthdayinputRef} type='datetime-local'></input>
            </div>
            <div>
                <label className='signuplabel'>Gender:</label>
                <select ref={genderinputRef}>
                    <option>Select Sex</option>
                    <option>Male</option>
                    <option>Female</option>
                    <option>Other</option>
                </select>
            </div>
            <div>
                <button className='signupbtn' type='button'  onClick={()=>{sendData();}}>Signup</button>
            </div>
        </form>
        <br></br>
       <Link to="/"><button className='loginbtn2'>Login</button></Link>
    </div>
    </div>
  )
}

export default Signup