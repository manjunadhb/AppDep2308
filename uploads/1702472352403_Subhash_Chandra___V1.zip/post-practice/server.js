const mongoose = require('mongoose');
const express = require('express');
const cors = require('cors');

let app = express();

app.use(cors());
app.use(express.json());


let port = 1234;

app.listen(port, () => {
    console.log(`Listening from port: ${port}`);
})

app.post('/signup', async (req,res) => {

    console.log(req.body);

    try {
        let newUser = new users({
            firstName: req.body.firstName,
            lastName: req.body.lastName,
            phone: req.body.phone,
            email: req.body.email,
            password: req.body.password,
            confirmPassword: req.body.confirmPassword,
            address: req.body.address,
            birthday: req.body.birthday,
            gender: req.body.gender,
        });

        await newUser.save();
        res.json({status: "Success", msg:"user created successfully"});
    } catch (error) {
        console.log("Unable to create",error);
        res.json({status: "failure", msg: error});
    }
})

let connectTODB = async () => {
    try {
        await mongoose.connect('mongodb+srv://subhash007:subhash007@cluster0.1kse9up.mongodb.net/userDetails?retryWrites=true&w=majority');

        console.log('Successfully Connected To Database');
    } catch (error) {
        console.log('Unable to Connect',error);
    }
}

let userSchema = new mongoose.Schema({
  firstName: String,
  lastName: String,
  phone: Number,
  email: String,
  password: String,
  confirmPassword: String,
  address: String,
  birthday: String,
  gender: String,
});

let users = new mongoose.model('user',userSchema);

connectTODB();


let connectTODB2 = async () => {

    try {
        await mongoose.connect('mongodb+srv://subhash007:subhash007@cluster0.1kse9up.mongodb.net/accountDetails?retryWrites=true&w=majority');

        console.log("Successfully Connected to Database");
    } catch (error) {
        console.log("Unable to Connect",error);
    }
}


connectTODB2();

app.get('/accountsInfo', async (req,res) => {

    const {profile, name, age, email, gender, country, location, interests, height, occupation} = req.query;

    let filter = {};

    if(profile){
        filter.profile = profile;
    }
    if(name){
        filter.name = name;
    }
    if(age){
        filter.age = age;
    }
    if(email){
        filter.email = email;
    }
    if(gender){
        filter.gender = gender;
    }
    if(country){
        filter.country = country;
    }
    if(location){
        filter.location = location;
    }
    if(interests){
        filter.interests = interests;
    }
    if(height){
        filter.height = height;
    }
    if(occupation){
        filter.occupation = occupation;
    }

    let filteredData = await accounts.find(filter);

    res.json(filteredData);   
    
})

app.get('/dropdownOptions', async (req,res) => {

    const gender = await accounts.distinct('gender');
    const age = await accounts.distinct('age');
    const country = await accounts.distinct('country');

    res.json({
        gender,
        age,
        country,
    });

})


let accountSchema = new mongoose.Schema({

    profile: String,
    name: String,
    age: Number,
    email: String,
    gender: String,
    country: String,
    location: String,
    interests: String,
    height: Number,
    occupation: String,
 
 });
 let accounts = new mongoose.model("account",accountSchema);
 


